<?php include('partials-front/menu.php');?>
<html>
    <body>
        <h3><b>Contact Number :+94 70 368 7630(L.S.I Medis)</b></h3>
        <br><br>
        CODSE212F-018 	    Nisila Chandunu
        CODSE212F-040 	    L.S.I. Medis
        CODSE212F-009	    P.A.D.B. Bhanuka Pannipitiya
        CODSE212F-024       A.R. Shazan Ahamed

        <h4>

        </h4>


    </body>
</html>

<?php include('partials-front/footer.php');?>