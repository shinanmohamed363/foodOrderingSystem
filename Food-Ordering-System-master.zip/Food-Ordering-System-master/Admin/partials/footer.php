 <!-- Footer section starts -->
 <div class = "footer">
            <div class="wrapper">
                <p class="text-center">2020 all rights reserved</p>
            </div>
            
        </div>
        <!-- Footer section Ends -->
    
    </body>
    
</html>